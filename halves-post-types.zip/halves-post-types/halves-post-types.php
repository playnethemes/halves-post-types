<?php
/*
 Plugin Name: Halves Custom Post Types
 Plugin URI: http://themeforest.net/user/screeynthemes
 Description: Custom post types for use in the Halves Restaurant theme. Please install this plugin to fully utilize the Halves theme.
 Author: Playne Themes
 Author URI: http://themeforest.net/user/playnethemes
 Version: 1.0
 */

/**
 * Gallery
 */
function halves_galerij_custom_init() {

    $halves_galerij_labels = array(
        'name'                  => esc_html_x('Gallery', 'post type general name', 'halves'),
        'singular_name'         => esc_html_x('Gallery item', 'post type singular name', 'halves'),
        'add_new'               => esc_html_x('Add new', 'Gallery item', 'halves'),
        'add_new_item'          => esc_html__('Add gallery item', 'halves'),
        'edit_item'             => esc_html__('Change gallery item', 'halves'),
        'new_item'              => esc_html__('New gallery item', 'halves'),
        'view_item'             => esc_html__('View gallery item', 'halves'),
        'search_items'          => esc_html__('Search gallery', 'halves'),
        'not_found'             => esc_html__('No items found', 'halves'),
        'not_found_in_trash'    => esc_html__('No items found in trash', 'halves'),
        'menu_name'             => esc_html__('Gallery', 'halves'),
    );

    $halves_galerij_args = array(
        'labels'                => $halves_galerij_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-images-alt',
        'menu_position'         => 1,
        'public'                => false,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','thumbnail')
    );

    register_post_type( 'our-gallery', $halves_galerij_args );

}
add_action( 'init', 'halves_galerij_custom_init' );

/**
 * menu
 */
function menu_custom_init() {

    $halves_menuitem_labels = array(
        'name'                  => esc_html_x( 'Menu', 'post type general name', 'halves' ),
        'singular_name'         => esc_html_x( 'Menu item', 'post type singular name', 'halves' ),
        'add_new'               => esc_html_x( 'Add new', 'Menu item', 'halves' ),
        'add_new_item'          => esc_html__( 'Add menu item', 'halves' ),
        'edit_item'             => esc_html__( 'Change menu item', 'halves' ),
        'new_item'              => esc_html__( 'New menu item', 'halves' ),
        'view_item'             => esc_html__( 'View menu item', 'halves' ),
        'search_items'          => esc_html__( 'Search menu items', 'halves' ),
        'not_found'             => esc_html__( 'No menu items found', 'halves' ),
        'not_found_in_trash'    => esc_html__( 'No menu items found in trash', 'halves' ),
        'menu_name'             => esc_html__( 'Menu', 'halves' )
    );

    $halves_menuitem_args = array(
        'labels'                => $halves_menuitem_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-clipboard',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'public'                => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-menu', $halves_menuitem_args );

    // Initialize New Taxonomy Labels
    $halves_menuitem_category_labels = array(
        'name'              => _x( 'Categorieën', 'taxonomy general name', 'halves' ),
        'singular_name'     => _x( 'Categorie', 'taxonomy singular name', 'halves' ),
        'search_items'      =>  __( 'Zoek categorieën', 'halves' ),
        'all_items'         => __( 'Alle categorieën', 'halves' ),
        'parent_item'       => __( 'Parent Categorie', 'halves' ),
        'parent_item_colon' => __( 'Parent Categorie:', 'halves' ),
        'edit_item'         => __( 'Wijzig Categorieën,', 'halves' ),
        'update_item'       => __( 'Update Categorie', 'halves' ),
        'add_new_item'      => __( 'Voeg nieuwe categorie toe', 'halves' ),
        'new_item_name'     => __( 'Nieuwe categorie naam', 'halves' ),
    );

    // Custom taxonomy for Project Tags
    register_taxonomy('menu-categories',array('our-menu'), array(
        'hierarchical'      => true,
        'labels'            => $halves_menuitem_category_labels,
        'show_ui'           => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'categories' ),
    ));

}
add_action('init', 'menu_custom_init');

/**
 * testimonials
 */
function halves_testimonials_customposttype_init() {

    $halves_testimonials_labels = array(
        'name'                  => esc_html_x('Testimonials', 'post type general name', 'halves'),
        'singular_name'         => esc_html_x('Testimonial', 'post type singular name', 'halves'),
        'add_new'               => esc_html_x('Add new', 'testimonial', 'halves'),
        'add_new_item'          => esc_html__('Add testimonial', 'halves'),
        'edit_item'             => esc_html__('Edit testimonial', 'halves'),
        'new_item'              => esc_html__('New testimonial', 'halves'),
        'view_item'             => esc_html__('View testimonial', 'halves'),
        'search_items'          => esc_html__('Search testimonials', 'halves'),
        'not_found'             => esc_html__('No testimonials found', 'halves'),
        'not_found_in_trash'    => esc_html__('No testimonials found in trash', 'halves'),
        'menu_name'             => esc_html__( 'Testimonials', 'halves' )
    );

    $halves_testimonials_args = array(
        'labels'                => $halves_testimonials_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-format-status',
        'menu_position'         => 1,
        'public'                => false,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-testimonials', $halves_testimonials_args );

}
add_action( 'init', 'halves_testimonials_customposttype_init' );

/**
 * Features
 */
function halves_features_customposttype_init() {

    $halves_feature_labels = array(
        'name'                  => esc_html_x( 'Features', 'post type general name', 'halves' ),
        'singular_name'         => esc_html_x( 'Feature', 'post type singular name', 'halves' ),
        'add_new'               => esc_html_x( 'Add new', 'feature', 'halves' ),
        'add_new_item'          => esc_html__( 'Add feature', 'halves' ),
        'edit_item'             => esc_html__( 'Edit feature', 'halves' ),
        'new_item'              => esc_html__( 'New feature', 'halves' ),
        'view_item'             => esc_html__( 'View feature', 'halves' ),
        'search_items'          => esc_html__( 'Search features', 'halves' ),
        'not_found'             => esc_html__( 'No features found', 'halves' ),
        'not_found_in_trash'    => esc_html__( 'No features found in trash', 'halves' ),
        'menu_name'             => esc_html__( 'Features', 'halves' )
    );

    $halves_feature_args = array(
        'labels'                => $halves_feature_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-editor-ul',
        'menu_position'         => 1,
        'public'                => false,
        'publicly_queryable'    => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-features', $halves_feature_args );

}
add_action('init', 'halves_features_customposttype_init');

/**
 * Team
 */
function halves_team_customposttype_init() {

    $halves_team_labels = array(
        'name'                  => esc_html_x( 'Team', 'post type general name', 'halves' ),
        'singular_name'         => esc_html_x( 'Member', 'post type singular name', 'halves' ),
        'add_new'               => esc_html_x( 'Add new', 'member', 'halves' ),
        'add_new_item'          => esc_html__( 'Add member', 'halves' ),
        'edit_item'             => esc_html__( 'Edit member', 'halves' ),
        'new_item'              => esc_html__( 'New member', 'halves' ),
        'view_item'             => esc_html__( 'View member', 'halves' ),
        'search_items'          => esc_html__( 'Search members', 'halves' ),
        'not_found'             => esc_html__( 'No members found', 'halves' ),
        'not_found_in_trash'    => esc_html__( 'No members found in trash', 'halves' ),
        'menu_name'             => esc_html__( 'Team', 'halves' )
    );

    $halves_team_args = array(
        'labels'                => $halves_team_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-groups',
        'menu_position'         => 1,
        'public'                => false,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail','excerpt')
    );

    register_post_type( 'our-team', $halves_team_args );

}
add_action('init', 'halves_team_customposttype_init');